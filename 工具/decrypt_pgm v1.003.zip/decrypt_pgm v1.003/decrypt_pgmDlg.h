// decrypt_pgmDlg.h : header file
//

#if !defined(AFX_DECRYPT_PGMDLG_H__BC7E33B5_D608_48C4_A9CF_AF501C312DCF__INCLUDED_)
#define AFX_DECRYPT_PGMDLG_H__BC7E33B5_D608_48C4_A9CF_AF501C312DCF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// license:BSD-3-Clause
// copyright-holders:Andreas Naive,David Haywood
#ifndef _IGS036CRYPT_H_
#define _IGS036CRYPT_H_




// the triggers describe under what conditions are every one of the 16 XORs activated




#endif
/////////////////////////////////////////////////////////////////////////////
// CDecrypt_pgmDlg dialog

class CDecrypt_pgmDlg : public CDialog
{
// Construction
public:
	CDecrypt_pgmDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDecrypt_pgmDlg)
	enum { IDD = IDD_DECRYPT_PGM_DIALOG };
	CComboBox	li1;
	CString	sPathProm;
	CString	sPathu12;
	CString	sPathu16;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDecrypt_pgmDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDecrypt_pgmDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnOpenProm();
	afx_msg void OnOPENu12();
	afx_msg void OnOPENu16();
	afx_msg void OnProm();
	afx_msg void Onu12u16();
	afx_msg void OnDropdownCombo1();
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void Decrypt2();
	void PreSubclassWindow() ;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DECRYPT_PGMDLG_H__BC7E33B5_D608_48C4_A9CF_AF501C312DCF__INCLUDED_)
