// decrypt_pgmDlg.cpp : implementation file
//

#include "stdafx.h"
#include "decrypt_pgm.h"
#include "decrypt_pgmDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#include "decrypt_PROM_PGM_1.h"
#include "decrypt_PROM_PGM_2.h"
int nSel=-1;


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDecrypt_pgmDlg dialog

CDecrypt_pgmDlg::CDecrypt_pgmDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDecrypt_pgmDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDecrypt_pgmDlg)
	sPathProm = _T("");
	sPathu12 = _T("");
	sPathu16 = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDecrypt_pgmDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDecrypt_pgmDlg)
	DDX_Control(pDX, IDC_COMBO1, li1);
	DDX_Text(pDX, IDC_PATH_PROM, sPathProm);
	DDX_Text(pDX, IDC_PATH_u12, sPathu12);
	DDX_Text(pDX, IDC_PATH_u16, sPathu16);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDecrypt_pgmDlg, CDialog)
	//{{AFX_MSG_MAP(CDecrypt_pgmDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OPEN_PROM, OnOpenProm)
	ON_BN_CLICKED(IDC_OPEN_u12, OnOPENu12)
	ON_BN_CLICKED(IDC_OPEN_u16, OnOPENu16)
	ON_BN_CLICKED(IDC_PROM, OnProm)
	ON_BN_CLICKED(IDC_u12u16, Onu12u16)
	ON_CBN_DROPDOWN(IDC_COMBO1, OnDropdownCombo1)
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo1)
	ON_MESSAGE(WM_DROPFILES,OnDropFiles)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDecrypt_pgmDlg message handlers

BOOL CDecrypt_pgmDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	// TODO: Add extra initialization here
	CRect rtClient;
	GetWindowRect(rtClient);  	
	//::GetWindowRect()
	CString a;
	a.Format("%u-%u",rtClient.Width(),rtClient.Height());
	::SetWindowPos(m_hWnd, HWND_TOPMOST,
		400,//rtClient.left,
		200,//rtClient.top,
		rtClient.Width(), rtClient.Height(),SWP_SHOWWINDOW);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDecrypt_pgmDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDecrypt_pgmDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDecrypt_pgmDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}




void CDecrypt_pgmDlg::Decrypt2() 
{
	// TODO: Add your control notification handler code here
const UINT32 M2=0x1000000;

	//�ֱ��ȡ 12 16�ļ�
	FILE *ft=fopen(sPathu12,"rb");
	if(0==ft)
	{
		AfxMessageBox("�޷���pgm��u12�ļ�");
		return;
	}
	HGLOBAL hg2=GlobalAlloc(GPTR,M2);
	UINT16 *uc2=(UINT16*)hg2;
	rewind(ft);
	fread(uc2,2,M2/2,ft);
	fclose(ft);

	FILE *fp=fopen(sPathu16,"rb");
	if(0==fp)
	{
		AfxMessageBox("�޷���pgm��u16�ļ�");
		return;
	}
	HGLOBAL hg=GlobalAlloc(GPTR,M2);
	UINT16 *uc=(UINT16*)hg;
	rewind(fp);
	fread(uc,2,M2/2,fp);
	fclose(fp);





	//�ϲ�
	HGLOBAL hgAll=GlobalAlloc(GPTR,2*M2);
	UINT32 *puiAll=(UINT32*)hgAll;
	for (UINT j=0;j<M2/2;j++)
	{
		puiAll[j]=(UINT32)((UINT32)(((UINT32)uc[j])<<16)+((UINT32)uc2[j]));
	}

	UINT16 *pustemp=(UINT16*)puiAll;
	iga_u12_decode(pustemp,2*M2,0x4761);
	iga_u16_decode(pustemp,2*M2,0xc79f);



	//�ָ�
	UINT32 *puiForExtract=(UINT32*)pustemp;

	

	

	char c[MAX_PATH];
	GetModuleFileName(0,c,MAX_PATH);
	CString sDir=c,sDir12,sDir16,sDir26;
	sDir=sDir.Left(sDir.ReverseFind('\\')+1);
	sDir12=sDir+"ig-a_bml_decrypt.u12";
	sDir16=sDir+"ig-a_bmh_decrypt.u16";
	sDir26=sDir+"(12_16)_decrypt.bin";

	FILE *fAll=fopen(sDir26,"wb");
	if(0==fAll)
	{
		AfxMessageBox("�޷��������ܵ�12_16�ϲ��ļ�!");
		return;
	}
	rewind(fAll);
	fwrite(puiForExtract,4,M2/2,fAll);
	fclose(fAll);

	/*
	FILE *ft2=fopen(sDir12,"wb");
	if(0==ft2)
	{
		AfxMessageBox("�޷��������ܵ�u12�ļ�!");
		return;
	}
	rewind(ft2);
	fwrite(uc2,2,M2/2,ft2);
 	fclose(ft2);

	FILE *fp2=fopen(sDir16,"wb");
	if(0==fp2)
	{
		AfxMessageBox("�޷��������ܵ�u16�ļ�!");
		return;
	}
	rewind(fp2);
	fwrite(uc,2,M2/2,fp2);
	fclose(fp2);
	*/

	if (hg)
	{
		GlobalFree(hg);
		hg=0;
	}
	if (hg2)
	{
		GlobalFree(hg2);
		hg2=0;
	}
	if (hgAll)
	{
		GlobalFree(hgAll);
		hgAll=0;
	}
	
	
	MessageBox("�ɹ�����pgm��12_16���ܺϲ��ļ�!!\r\n�ļ�λ��:"+sDir26,"��ϲ",MB_ICONINFORMATION);


}



void CDecrypt_pgmDlg::OnOpenProm() 
{
	// TODO: Add your control notification handler code here
	CFileDialog fd(1,0,0,OFN_NOCHANGEDIR,"���м���PGM ��PROM�ļ�|*.*||",NULL);
	fd.m_ofn.lStructSize = 88;
	fd.m_ofn.lpstrTitle="��򿪼��ܵ�PGM PROM�ļ�";
	if (IDOK==fd.DoModal())
	{
		sPathProm=fd.GetPathName();
		SetDlgItemText(IDC_PATH_PROM,sPathProm);
	}
}

void CDecrypt_pgmDlg::OnOPENu12() 
{
	// TODO: Add your control notification handler code here
	CFileDialog fd(1);
	if (IDOK==fd.DoModal())
	{
		sPathu12=fd.GetPathName();
		SetDlgItemText(IDC_PATH_u12,sPathu12);
	}	
}

void CDecrypt_pgmDlg::OnOPENu16() 
{
	// TODO: Add your control notification handler code here
	CFileDialog fd(1);
	if (IDOK==fd.DoModal())
	{
		sPathu16=fd.GetPathName();
		SetDlgItemText(IDC_PATH_u16,sPathu16);
	}	
}

void CDecrypt_pgmDlg::OnProm() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (-1==nSel)
	{
		AfxMessageBox("��ѡ����Ϸ����!");
		return;
	}
	FILE *f1=fopen(sPathProm,"rb");
	if (NULL==f1)
	{
		AfxMessageBox("pgm���ܵ�PROM�ļ�������!");
		return;
	}
	fseek(f1,0,2);
	int nf=ftell(f1);
	
	HGLOBAL hg=GlobalAlloc(GPTR,nf);
	rewind(f1);
	unsigned short *pus=(unsigned short*)hg;
	fread(pus,2,nf/2,f1);

	//orleg2 m312cn cjddzsp cjdh2 kov3 kov2 ddpdoj
	switch (nSel)
		{
		case 0:
			pgm_decrypt_kov(pus,nf);
			break;
		case 1:
			pgm_decrypt_kovsh(pus,nf);
			break;
		case 2:
			pgm_decrypt_kovshp(pus,nf);
			break;
		case 3:
			pgm_decrypt_kov2(pus,nf);
			break;
		case 4:
			pgm_decrypt_kov2p(pus,nf);
			break;
		case 5:
			pgm_decrypt_theglad(pus,nf);
			break;
		case 6:
			pgm_decrypt_oldsplus(pus,nf);
			break;
		case 7:
			pgm_decrypt_photoy2k(pus,nf);
			break;
		case 8:
			pgm_decrypt_py2k2(pus,nf);
			break;
		case 9:
			pgm_decrypt_pstar(pus,nf);
			break;
		case 10:
			pgm_decrypt_dfront(pus,nf);
			break;
		case 11:
			pgm_decrypt_ddp2(pus,nf);
			break;
		case 12:
			pgm_decrypt_mm(pus,nf);
			break;
		case 13:
			pgm_decrypt_killbldp(pus,nf);
			break;
		case 14:
			pgm_decrypt_svg(pus,nf);
			break;
		case 15:
			pgm_decrypt_svgpcb(pus,nf);
			break;
		case 16:
			pgm_decrypt_ket(pus,nf);
			break;
		case 17:
			pgm_decrypt_espgal(pus,nf);
			break;
		case 18:
			pgm_decrypt_happy6in1(pus,nf);
			break;
		case 19:
			pgm_decrypt_puzzli2(pus,nf);
			break;
		case 20:
			pgm_decrypt_lhzb3(pus,nf);
			break;
		case 21:
			pgm_decrypt_lhzb4(pus,nf);
			break;
		case 22:
			pgm_decrypt_sddz(pus,nf);
			break;
		case 23:
			pgm_decrypt_sdwx(pus,nf);
			break;
		case 24:
			pgm_decrypt_chessc2(pus,nf);
			break;
		case 25:
			pgm_decrypt_kov(pus,nf);
			break;
		case 26:
			pgm_decrypt_klxyj(pus,nf);
			break;
		case 27:
			pgm_decrypt_gonefsh2(pus,nf);
			break;
		case 28:
			pgm_decrypt_mgfx(pus,nf);
			break;
		case 29:
			pgm_decrypt_fearless(pus,nf);
			break;
		case 30:
			pgm_decrypt_pgm3in1(pus,nf);
			break;
		case 31:
			rom=pus;
			size=nf;
			decrypter_rom(orleg2_key);	
			break;
		case 32:
			rom=pus;
			size=nf;
			decrypter_rom(m312cn_key);
			break;
		case 33:
			rom=pus;
			size=nf;
			decrypter_rom(cjddzsp_key);
			break;
		case 34:
			rom=pus;
			size=nf;
			decrypter_rom(cjdh2_key);
			break;
		case 35:
			rom=pus;
			size=nf;
			decrypter_rom(kov3_key);
			break;
		case 36:
			rom=pus;
			size=nf;
			decrypter_rom(kov2_key);
			break;
		case 37:
			rom=pus;
			size=nf;
			decrypter_rom(ddpdoj_key);
			break;
		case 38:
			rom=pus;
			size=nf;
			decrypter_rom_encrypt(orleg2_key);	
			break;
		case 39:
			rom=pus;
			size=nf;
			decrypter_rom_encrypt(m312cn_key);
			break;
		case 40:
			rom=pus;
			size=nf;
			decrypter_rom_encrypt(cjddzsp_key);
			break;
		case 41:
			rom=pus;
			size=nf;
			decrypter_rom_encrypt(cjdh2_key);
			break;
		case 42:
			rom=pus;
			size=nf;
			decrypter_rom_encrypt(kov3_key);
			break;
		case 43:
			rom=pus;
			size=nf;
			decrypter_rom_encrypt(kov2_key);
			break;
		case 44:
			rom=pus;
			size=nf;
			decrypter_rom_encrypt(ddpdoj_key);
			break;

		default:
			AfxMessageBox("��ѡ����Ϸ����!");
			return;
			break;
		}
	
	CString sDecryptDir;
	/*
	char c[MAX_PATH];
	GetModuleFileName(0,c,MAX_PATH);
	CString sDir=c,sDecryptDir;
	sDir=sDir.Left(sDir.ReverseFind('\\')+1);
	sDir+="prom_decrypt.bin";
	*/
	int nPos=sPathProm.ReverseFind('\\');
	sDecryptDir=sPathProm+"_promdecrypt.bin";
	FILE *fp=fopen(sDecryptDir,"wb");
	if (NULL==fp)
	{
		AfxMessageBox("�޷��������ܵ�pgm��PROM�ļ�!");
		return;
	}
	rewind(fp);
	fwrite(pus,2,nf/2,fp);
	fclose(fp);
	if(hg)
	{
		GlobalFree(hg);
		hg=0;
	}
	MessageBox("�ɹ�����pgm��PROM�ļ�!!\r\n�ļ�λ��:"+sDecryptDir,"��ϲ",MB_ICONINFORMATION);
}

void CDecrypt_pgmDlg::Onu12u16() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	Decrypt2();
}

void CDecrypt_pgmDlg::OnDropdownCombo1() 
{
	// TODO: Add your control notification handler code here
	return;
// 	li1.ResetContent();
// 	li1.AddString("orleg2");
// 	li1.AddString("m312cn");
// 	li1.AddString("cjddzsp");
// 	li1.AddString("cjdh2");
// 	li1.AddString("kov3");
// 	li1.AddString("kov2");
// 	li1.AddString("ddpdoj");
}

void CDecrypt_pgmDlg::OnSelchangeCombo1() 
{
	// TODO: Add your control notification handler code here
	nSel=li1.GetCurSel();
}
void CDecrypt_pgmDlg::OnDropFiles(HDROP hDropInfo)
{
	//AfxMessageBox("1");
	CRect  rEdit,rEditDir;   
    
	CEdit *pm_edit=((CEdit*)(GetDlgItem(IDC_PATH_PROM)));
	CEdit *pm_edit_dir;//((CEdit*)(GetDlgItem(IDC_DECRYPT_DIR_PATH)));
	pm_edit->GetWindowRect(rEdit);//��ÿؼ�������
	pm_edit_dir->GetWindowRect(rEditDir);
	POINT   pos;   
    
	::GetCursorPos(&pos);  //��ù�굱ǰ����Ļ����   
    
	//��������edit�ؼ��У�����ʾ�϶����ļ�����������Ӧ�����������ʲô������   
	CHAR   cFileName[256];   
	
	UINT   uFileCount,   u;   
	uFileCount   =   
		::DragQueryFile(hDropInfo,   -1,	cFileName,   sizeof(cFileName));   
	//�������ļ����� 
	CString ss;
	ss.Format("%u %u-%u %u %u %u",pos.x,pos.y,rEdit.left,rEdit.right,rEdit.top,rEdit.bottom);
	//SetWindowText(ss);
	if((pos.x   >   rEdit.left)   &&   (pos.x     
		<   rEdit.right)     
		&&   (pos.y   <   rEdit.bottom)   
		&&   (pos.y   >   rEdit.top))   
	{   
		for(u   =   0;u <  uFileCount;   u++)
		{   
			::DragQueryFile(hDropInfo,   u,   
				cFileName,   sizeof(cFileName));   //ȡ��ÿ���ļ����ļ���   
			
			sPathProm.Format("%s",cFileName);
			//AfxMessageBox(sPathCrypt);
			SetDlgItemText(IDC_PATH_PROM,sPathProm);
			
		}   
		
		::DragFinish(hDropInfo);   
	} 
	
	
}
void CDecrypt_pgmDlg::PreSubclassWindow() 
{
	DragAcceptFiles( TRUE );
	
	CWnd::PreSubclassWindow();
}