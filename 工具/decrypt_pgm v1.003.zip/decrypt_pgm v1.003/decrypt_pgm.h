// decrypt_pgm.h : main header file for the DECRYPT_PGM application
//

#if !defined(AFX_DECRYPT_PGM_H__78D4F0F5_B4D9_4E27_AA63_AA5E22B037DC__INCLUDED_)
#define AFX_DECRYPT_PGM_H__78D4F0F5_B4D9_4E27_AA63_AA5E22B037DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDecrypt_pgmApp:
// See decrypt_pgm.cpp for the implementation of this class
//

class CDecrypt_pgmApp : public CWinApp
{
public:
	CDecrypt_pgmApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDecrypt_pgmApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDecrypt_pgmApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DECRYPT_PGM_H__78D4F0F5_B4D9_4E27_AA63_AA5E22B037DC__INCLUDED_)
