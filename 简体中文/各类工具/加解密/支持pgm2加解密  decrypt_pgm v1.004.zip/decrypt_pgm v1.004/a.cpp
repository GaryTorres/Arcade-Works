#include "a.h"
#include <StdAfx.h>
// license:BSD-3-Clause
// copyright-holders:Andreas Naive,David Haywood

igs036_decryptor(const UINT16* game_key);
LPVOID decrypter_rom(CString pcPat,UINT size,UINT16 *rom);
UINT16 decrypt(UINT16 cipherword, int word_address);
UINT16 deobfuscate(UINT16 cipherword, int word_address);


const UINT16* key;

static int (*rot_enabling[16][4])(int);
static int (*rot_direction[4][8])(int);
static const UINT16 triggers[16][2];

int rotation(int address);
UINT16 rol(UINT16 num, int shift);
int rot_enabled(int address, const int* group) ;
int rot_group(int address, const int* group);


extern const UINT16  orleg2_key[0x100];
extern const UINT16  m312cn_key[0x100];
extern const UINT16 cjddzsp_key[0x100];
extern const UINT16   cjdh2_key[0x100];
extern const UINT16    kov3_key[0x100];
extern const UINT16    kov2_key[0x100];
extern const UINT16  ddpdoj_key[0x100];

#define BIT(x,n) (((x)>>(n))&1)
#define BITSWAP16(val,B15,B14,B13,B12,B11,B10,B9,B8,B7,B6,B5,B4,B3,B2,B1,B0) \
	((BIT(val,B15) << 15) | (BIT(val,B14) << 14) | (BIT(val,B13) << 13) | (BIT(val,B12) << 12) | \
	(BIT(val,B11) << 11) | (BIT(val,B10) << 10) | (BIT(val, B9) <<  9) | (BIT(val, B8) <<  8) | \
	(BIT(val, B7) <<  7) | (BIT(val, B6) <<  6) | (BIT(val, B5) <<  5) | (BIT(val, B4) <<  4) | \
		(BIT(val, B3) <<  3) | (BIT(val, B2) <<  2) | (BIT(val, B1) <<  1) | (BIT(val, B0) <<  0))
/****************************************************************************
IGS036 encryption emulation

The encryption used by the IGS036 seems to be another iteration over
previous IGS encryption schemes. Basically, it consists on a rotation-based
non-trivial obfuscation layered upon a simple address-based XOR encryption
(similar to the ones found in previous IGS circuits).

The scheme works on 16-bits words and is probably designed to depend on 24 bits of
(word-) address; in what follows, we will refer to the 8 lowest ones simply as the
lowest bits of the address, and the other 16 as the highest bits the address.

The address-based XOR is thought to be comprised of 16 one-bit XOR controlled
by a certain combination of one or two of the highest address bits (but only
15 of them are observed, probably due to the fact that no game uses more than
2^22 of the 2^24 address space). Every one of the one-bit XORs affects a different bit
of the word. The game key acts by masking on/off those XORs for every combination
of the lowest address bits. Thus, a complete key can be described by 256 16-bits values.
This use of the key is pretty similar to the one found in previous instantiations of
IGS circuits.

What is new in the IGS036 is the use of an obfuscation working this way:

1) The highest bits of the address are split in 4 groups, every of which controls
a rotation by a shift of (plus or minus) 9, 1, 2 and 4 respectively.
2) For every address, the highest bit of the group set in the address controls
the activation/deactivation of the rotation for his group, using an associated
(and fixed) boolean function depending on the lowest bits of the address.
3) If the group rotation is to be activated according to 2), then another
fixed group-level boolean functions (again, depending on the lowest bits of the
address) control the direction (left or right) of the rotation.
4) One of the groups (the associated with the shift by 9) interacts with the other
three by inverting (when active itself) the activation/deactivation patterns of
the other three.
5) The lowest bits of the address control a further rotation(independent
on the highest bits of the address).
6) Besides, a global bitswap is present (which can be considered either part of the
obfuscation or of the encryption, as is done in the interface between both).

All the associated boolean functions are clearly of low complexity, so it should
be expected that the hardware is calculating them that way rather than using
lookup tables or otherwise. It must be stressed that this obfuscation is done
system-wide without dependence on the game keys.

On a different note, the unused tail of the ROMs are pattern-filled and, more interestingly,
that region appears to be hiding 20-bytes values (SHA-1 hashes?) located at
positions which vary per set. See the table below.

driver      20-bytes value position in the ROM
---------   ----------------------------------
orleg2o     $763984-$763997
orleg2      $76C77C-$76C78F
kov3        $718040-$718053

TO-DO: complete the table with the 20-bytes values

*****************************************************************************/


LPVOID decrypter_rom(UINT16 *&rom,UINT size)
{
// 	int size = region->bytes();
// 	UINT16* rom = (UINT16*)region->base();
// 	FILE *fp=fopen(pcPat,"rb");
// 	if (NULL==fp)
// 	{
// 		return 0;
// 	}
// 	rewind(fp);
// 	HGLOBAL hg=GlobalAlloc(GMEM_FIXED,size);
// 	UCHAR *puc=(UCHAR*)hg;
// 
// 	fread(puc,1,size,fp);
// 	fclose(fp);
// 	UINT16 *rom=(UINT16*)puc;
	for (int i = 0; i < size / 2; i++)
	{
		rom[i] = decrypt(rom[i], i);
	}
	return 0;
}

UINT16 decrypt(UINT16 cipherword, int word_address)
{
	// key-independent manipulation
	int aux = deobfuscate(cipherword, word_address);

	// key-dependent manipulation
	for (int i=0; i<16; ++i)
	{
		if (BIT(key[word_address&0xff],i))
		{
			if (((word_address>>8)&triggers[i][0]) == triggers[i][1])
				aux ^= (1<<i);
		}
	}

	return aux^0x1a3a;
}

UINT16 deobfuscate(UINT16 cipherword, int word_address)
{
	// key-independent manipulation
	int shift = rotation(word_address);
	int aux = rol(cipherword, shift);
	aux = BITSWAP16(aux, 10,9,8,7,0,15,6,5,   14,13,4,3,12,11,2,1);

	return aux;
}

int rotation(int address)
{
	const int group15[] = {15,11, 7, 5};  // 15 is a guess
	const int group14[] = {14, 9, 3, 2};  // 14 is a guess
	const int group13[] = {13,10, 6, 1};
	const int group12[] = {12, 8, 4, 0};

	// rotation depending on all the address bits
	int enabled0 = rot_enabled(address, group15);
	int rot = enabled0 * rot_group(address, group15) * 9;

	int enabled1 = enabled0 ^ rot_enabled(address, group14);
	rot += enabled1 * rot_group(address, group14) * 1;

	int enabled2 = enabled0 ^ rot_enabled(address, group13);
	rot += enabled2 * rot_group(address, group13) * 2;

	int enabled3 = enabled0 ^ rot_enabled(address, group12);
	rot += enabled3 * rot_group(address, group12) * 4;

	// block-independent rotation (just depending on the lowest 8 bits)
	int rot2  = 4*BIT(address,0);
	rot2 += 1*BIT(address,4)*(BIT(address,0)*2-1);
	rot2 += 4*BIT(address,3)*(BIT(address,0)*2-1);
	rot2 *= (BIT(address,7)|(BIT(address,0)^BIT(address,1)^1))*2-1;
	rot2 += 2*((BIT(address,0)^BIT(address,1))&(BIT(address,7)^1));

	return (rot+rot2)&0xf;
}

int rot_enabled(int address, const int* group)
{
	int enabled = 0;
	for (int j=0; j<4; ++j)
	{
		if (BIT(address,8+group[j]))
		{
			int aux = address ^ (0x1b*BIT(address,2));
			enabled = rot_enabling[group[j]][aux&3](aux);
			break;
		}
	}

	return enabled;
}

int rot_group(int address, const int* group)
{
	int aux = rot_direction[group[0]&3][address&7](address);
	return (aux*2)-1;
}

UINT16 rol(UINT16 num, int shift)
{
	UINT16 r = num<<shift;
	UINT16 l = num>>(16-shift);

	return r|l;
}